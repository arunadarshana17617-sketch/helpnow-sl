﻿'use client';
// src/app/partner/dashboard/page.js
import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

import {
  CheckCircle2, XCircle, Clock, Loader2, CalendarDays,
  MapPin, Phone, Briefcase, ChevronDown, ChevronUp, User,
  AlertCircle, PlayCircle, BadgeCheck, Navigation, NavigationOff
} from 'lucide-react';

// ── Location Toggle Component ────────────────────────────────────
function LocationToggle() {
  const [enabled, setEnabled] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [permDenied, setPermDenied] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // ✅ interval ref — location ON karagena innakota hama 30s kata GPS update karanna
  const intervalRef = useRef(null);

  // ── Background GPS push function ─────────────────────────────
  // Location ON innakota silently GPS coordinates update karanawa (no UI feedback)
  const pushLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          await fetch('/api/partner/location', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              enabled: true,
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            }),
          });
          setLastUpdated(new Date().toISOString());
        } catch (_) {
          // Silent fail — next interval try karanawa
        }
      },
      () => {
        // GPS error — silent fail
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  };

  // ── Start / stop interval based on 'enabled' ─────────────────
  useEffect(() => {
    if (enabled) {
      // ✅ Immediately push GPS — 30s wait ekak na
      pushLocation();
      // ✅ Interval start — hama 30s kata GPS push
      intervalRef.current = setInterval(pushLocation, 30_000);
    } else {
      // ✅ Interval clear — location OFF wunama stop
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    // Cleanup: component unmount wunama clear
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [enabled]);

  // Fetch current status on mount
  useEffect(() => {
    fetch('/api/partner/location')
      .then(r => r.json())
      .then(({ data }) => {
        if (data) {
          setEnabled(data.locationEnabled);
          setLastUpdated(data.locationUpdatedAt);
        }
      })
      .catch(console.error);

    // Check permission state silently (no prompt)
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'geolocation' }).then(result => {
        if (result.state === 'denied') setPermDenied(true);
        result.onchange = () => {
          setPermDenied(result.state === 'denied');
          if (result.state !== 'denied') setError(null);
        };
      }).catch(() => {});
    }
  }, []);

  const handleToggle = async () => {
    if (!enabled && permDenied) {
      setError('denied');
      return;
    }

    setToggling(true);
    setError(null);
    try {
      const body = { enabled: !enabled };

      // Turning ON → grab fresh GPS coords
      if (!enabled) {
        const pos = await new Promise((res, rej) =>
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 8000 })
        );
        body.lat = pos.coords.latitude;
        body.lng = pos.coords.longitude;
      }

      const res = await fetch('/api/partner/location', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed');
      setEnabled(json.data.locationEnabled);
      setLastUpdated(json.data.locationUpdatedAt);
      setError(null);
    } catch (err) {
      if (err.code === 1) {
        setPermDenied(true);
        setError('denied');
      } else {
        setError(err.message || 'Something went wrong');
      }
    } finally {
      setToggling(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5">
      <div className="flex items-center gap-4">
        {/* Icon */}
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
          enabled ? 'bg-green-100' : 'bg-gray-100'
        }`}>
          {enabled
            ? <Navigation size={22} className="text-green-600" />
            : <NavigationOff size={22} className="text-gray-400" />
          }
        </div>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <p className="font-bold text-blue-950">Live Location</p>
          <p className="text-sm text-gray-500">
            {enabled
              ? 'Customers can find you nearby 🟢'
              : 'Your location is hidden from customers'}
          </p>
          {/* ✅ Live update timestamp */}
          {lastUpdated && enabled && (
            <p className="text-xs text-green-600 mt-0.5 font-medium">
              📍 Updated {new Date(lastUpdated).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </p>
          )}
          {lastUpdated && !enabled && (
            <p className="text-xs text-gray-400 mt-0.5">
              Last: {new Date(lastUpdated).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
            </p>
          )}
        </div>

        {/* Toggle switch */}
        <button
          onClick={handleToggle}
          disabled={toggling}
          aria-label={enabled ? 'Disable location' : 'Enable location'}
          className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors flex-shrink-0 ${
            enabled ? 'bg-green-500' : permDenied ? 'bg-amber-300' : 'bg-gray-300'
          } ${toggling ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'}`}
        >
          <span
            className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-md transition-transform ${
              enabled ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
          {toggling && (
            <Loader2 size={12} className="absolute right-1 text-white animate-spin" />
          )}
        </button>
      </div>

      {/* ✅ Live tracking active badge */}
      {enabled && (
        <div className="mt-3 flex items-center gap-2 text-xs text-green-700 bg-green-50 border border-green-200 rounded-xl px-3 py-2">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse inline-block" />
          Live tracking active — GPS හැම තත්පර 30කට update වෙනවා
        </div>
      )}

      {/* Permission denied — step-by-step browser guide */}
      {error === 'denied' && (
        <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-4">
          <div className="flex items-start gap-2 mb-3">
            <AlertCircle size={16} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm font-semibold text-amber-800">Location access is blocked</p>
          </div>
          <p className="text-xs text-amber-700 mb-2">
            Browser eka location block kara tiyenawa. Mekata allow karanna:
          </p>
          <ul className="text-xs text-amber-700 space-y-1.5">
            <li>🔒 <strong>Chrome:</strong> Address bar eke lock icon click karanna → "Site settings" → Location → Allow</li>
            <li>🔒 <strong>Firefox:</strong> Lock icon click → Clear permission → Page reload karanna</li>
            <li>🔒 <strong>Edge:</strong> Lock icon → Permissions → Location → Allow</li>
            <li>📱 <strong>Mobile:</strong> Settings → Browser → Location → Allow</li>
          </ul>
          <p className="text-xs text-amber-600 mt-3">
            Allow karagena page reload (F5) karanna, habai toggle ON karanna.
          </p>
          <button
            onClick={() => setError(null)}
            className="mt-3 text-xs text-amber-600 underline hover:text-amber-800 transition"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Other errors */}
      {error && error !== 'denied' && (
        <div className="mt-3 flex items-center gap-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded-xl">
          <AlertCircle size={14} />
          {error}
        </div>
      )}
    </div>
  );
}
// ────────────────────────────────────────────────────────────────

const STATUS_CONFIG = {
  pending:     { label: 'Pending',     color: 'bg-yellow-100 text-yellow-700 border-yellow-200',  dot: 'bg-yellow-400' },
  confirmed:   { label: 'Confirmed',   color: 'bg-blue-100 text-blue-700 border-blue-200',        dot: 'bg-blue-400'   },
  in_progress: { label: 'In Progress', color: 'bg-purple-100 text-purple-700 border-purple-200',  dot: 'bg-purple-400' },
  completed:   { label: 'Completed',   color: 'bg-green-100 text-green-700 border-green-200',     dot: 'bg-green-400'  },
  cancelled:   { label: 'Cancelled',   color: 'bg-red-100 text-red-700 border-red-200',           dot: 'bg-red-400'    },
};

export default function PartnerDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [actionLoading, setActionLoading] = useState(null);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/partner');
    if (status === 'authenticated') fetchBookings();
  }, [status]);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/partner/bookings');
      const data = await res.json();
      if (data.success) setBookings(data.bookings);
      else setError(data.error || 'Bookings load karanna bari una');
    } catch {
      setError('Server error. Refresh karanna.');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (bookingId, newStatus) => {
    setActionLoading(bookingId);
    try {
      const res = await fetch(`/api/bookings/${bookingId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        setBookings(prev =>
          prev.map(b => b._id === bookingId ? { ...b, status: newStatus } : b)
        );
      } else {
        alert(data.error || 'Update failed');
      }
    } catch {
      alert('Server error');
    } finally {
      setActionLoading(null);
    }
  };

  const filtered = filter === 'all'
    ? bookings
    : bookings.filter(b => b.status === filter);

  const counts = bookings.reduce((acc, b) => {
    acc[b.status] = (acc[b.status] || 0) + 1;
    return acc;
  }, {});

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 size={40} className="animate-spin text-orange-500 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Loading bookings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-blue-950">My Bookings</h1>
            <p className="text-sm text-gray-500">{session?.user?.name} · Partner Dashboard</p>
          </div>
          <button
            onClick={fetchBookings}
            className="text-sm bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg transition font-medium"
          >
            Refresh
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-5">

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { key: 'pending',     label: 'Pending',   icon: Clock,        color: 'text-yellow-500' },
            { key: 'confirmed',   label: 'Confirmed',  icon: BadgeCheck,   color: 'text-blue-500'   },
            { key: 'in_progress', label: 'Active',     icon: PlayCircle,   color: 'text-purple-500' },
            { key: 'completed',   label: 'Done',       icon: CheckCircle2, color: 'text-green-500'  },
          ].map(({ key, label, icon: Icon, color }) => (
            <div key={key} className="bg-white rounded-xl border border-gray-200 p-4 text-center shadow-sm">
              <Icon size={22} className={`${color} mx-auto mb-1`} />
              <p className="text-2xl font-bold text-blue-950">{counts[key] || 0}</p>
              <p className="text-xs text-gray-500">{label}</p>
            </div>
          ))}
        </div>

        {/* ── Live Location Toggle ── */}
        <LocationToggle />
        {/* ──────────────────────── */}

        {/* Filter tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {['all', 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition border ${
                filter === f
                  ? 'bg-orange-500 text-white border-orange-500'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-orange-300'
              }`}
            >
              {f === 'all' ? `All (${bookings.length})` : STATUS_CONFIG[f]?.label}
              {f !== 'all' && counts[f] ? ` (${counts[f]})` : ''}
            </button>
          ))}
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center gap-2 bg-red-50 text-red-600 border border-red-200 rounded-xl px-4 py-3 text-sm">
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {/* Empty */}
        {filtered.length === 0 && !error && (
          <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
            <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Briefcase size={28} className="text-orange-400" />
            </div>
            <p className="text-gray-500 font-medium">No bookings found</p>
            <p className="text-sm text-gray-400 mt-1">
              {filter === 'all' ? 'Customers book karanna giya giya pennayi' : `No ${filter} bookings`}
            </p>
          </div>
        )}

        {/* Bookings list */}
        <div className="space-y-3">
          {filtered.map(booking => {
            const cfg = STATUS_CONFIG[booking.status] || STATUS_CONFIG.pending;
            const isExpanded = expandedId === booking._id;
            const isActing = actionLoading === booking._id;

            return (
              <div
                key={booking._id}
                className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
              >
                {/* Card header */}
                <div
                  className="flex items-start gap-4 p-4 cursor-pointer hover:bg-gray-50 transition"
                  onClick={() => setExpandedId(isExpanded ? null : booking._id)}
                >
                  <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center shrink-0">
                    <User size={18} className="text-orange-500" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-blue-950 truncate">{booking.customerName}</p>
                      <span className={`text-xs px-2.5 py-0.5 rounded-full border font-medium flex items-center gap-1 ${cfg.color}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
                        {cfg.label}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mt-0.5 truncate">{booking.serviceProfession} · {booking.serviceCategory}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-400 flex-wrap">
                      <span className="flex items-center gap-1">
                        <CalendarDays size={12} />
                        {new Date(booking.preferredDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin size={12} />
                        {booking.customerDistrict}
                      </span>
                    </div>
                  </div>

                  <div className="shrink-0 text-gray-400">
                    {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div className="border-t border-gray-100 px-4 pb-4 pt-3 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                      <div className="bg-gray-50 rounded-xl p-3 space-y-1.5">
                        <p className="font-semibold text-gray-700 text-xs uppercase tracking-wide mb-2">Customer Info</p>
                        <p className="flex items-center gap-2 text-gray-600">
                          <Phone size={13} className="text-gray-400" />
                          {booking.customerPhone || 'N/A'}
                        </p>
                        <p className="flex items-center gap-2 text-gray-600">
                          <MapPin size={13} className="text-gray-400" />
                          {booking.customerAddress}, {booking.customerCity}, {booking.customerDistrict}
                        </p>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-3 space-y-1.5">
                        <p className="font-semibold text-gray-700 text-xs uppercase tracking-wide mb-2">Job Details</p>
                        <p className="text-gray-600">
                          <span className="font-medium">Days:</span> {booking.estimatedDays} day(s)
                        </p>
                        <p className="text-gray-600">
                          <span className="font-medium">Daily Rate:</span> LKR {booking.dailyRate?.toLocaleString()}
                        </p>
                        <p className="text-gray-600">
                          <span className="font-medium">Est. Total:</span>{' '}
                          <span className="text-orange-500 font-bold">
                            LKR {((booking.dailyRate || 0) * (booking.estimatedDays || 1))?.toLocaleString()}
                          </span>
                        </p>
                      </div>
                    </div>

                    <div className="bg-blue-50 rounded-xl p-3">
                      <p className="text-xs font-semibold text-blue-700 uppercase tracking-wide mb-1">Job Description</p>
                      <p className="text-sm text-gray-700">{booking.jobDescription}</p>
                    </div>

                    {booking.customerNotes && (
                      <div className="bg-orange-50 rounded-xl p-3">
                        <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-1">Customer Notes</p>
                        <p className="text-sm text-gray-700">{booking.customerNotes}</p>
                      </div>
                    )}

                    <div className="flex gap-2 flex-wrap pt-1">
                      {booking.status === 'pending' && (
                        <>
                          <button
                            onClick={() => updateStatus(booking._id, 'confirmed')}
                            disabled={isActing}
                            className="flex items-center gap-1.5 bg-green-500 hover:bg-green-600 disabled:opacity-60 text-white px-4 py-2 rounded-xl text-sm font-semibold transition"
                          >
                            {isActing ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                            Accept
                          </button>
                          <button
                            onClick={() => updateStatus(booking._id, 'cancelled')}
                            disabled={isActing}
                            className="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 disabled:opacity-60 text-white px-4 py-2 rounded-xl text-sm font-semibold transition"
                          >
                            {isActing ? <Loader2 size={14} className="animate-spin" /> : <XCircle size={14} />}
                            Reject
                          </button>
                        </>
                      )}
                      {booking.status === 'confirmed' && (
                        <button
                          onClick={() => updateStatus(booking._id, 'in_progress')}
                          disabled={isActing}
                          className="flex items-center gap-1.5 bg-purple-500 hover:bg-purple-600 disabled:opacity-60 text-white px-4 py-2 rounded-xl text-sm font-semibold transition"
                        >
                          {isActing ? <Loader2 size={14} className="animate-spin" /> : <PlayCircle size={14} />}
                          Mark as Started
                        </button>
                      )}
                      {booking.status === 'in_progress' && (
                        <button
                          onClick={() => updateStatus(booking._id, 'completed')}
                          disabled={isActing}
                          className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-60 text-white px-4 py-2 rounded-xl text-sm font-semibold transition"
                        >
                          {isActing ? <Loader2 size={14} className="animate-spin" /> : <BadgeCheck size={14} />}
                          Mark Complete
                        </button>
                      )}
                      {(booking.status === 'completed' || booking.status === 'cancelled') && (
                        <p className="text-xs text-gray-400 self-center">No further actions available</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}